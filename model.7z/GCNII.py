"""
# -*- coding: utf-8 -*-
# @Author : Sun JJ
# @File : GCNII.py
# @Time : 2024/7/20 11:17
# code is far away from bugs with the god animal protecting
#         ┌─┐       ┌─┐
#      ┌──┘ ┴───────┘ ┴──┐
#      │                 │
#      │       ───       │
#      │  ─┬┘       └┬─  │
#      │                 │
#      │       ─┴─       │
#      │                 │
#      └───┐         ┌───┘
#          │         │
#          │         │
#          │         │
#          │         └──────────────┐
#          │                        │
#          │                        ├─┐
#          │                        ┌─┘
#          │                        │
#          └─┐  ┐  ┌───────┬──┐  ┌──┘
#            │ ─┤ ─┤       │ ─┤ ─┤
#            └──┴──┘       └──┴──┘
"""

import math
import torch
import pickle
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.utils.data import Dataset,DataLoader
from torch_geometric.nn import GCNConv, global_max_pool as gmp
import time


# Path
Feature_Path = "./Feature/"

# Seed
SEED = 2020
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.set_device(0)
    torch.cuda.manual_seed(SEED)

"""
# GraphPPIS parameters
EMBEDDING = "e" # b for BLOSUM62; e for evolutionary features (PSSM+HMM)
MAP_TYPE = "d" # d for discrete maps; c for continuous maps
MAP_CUTOFF = 14

INPUT_DIM = 67
HIDDEN_DIM = 256
LAYER = 10
DROPOUT = 0.1
ALPHA = 0.5
LAMBDA = 1.3
VARIANT = True # From GCNII

LEARNING_RATE = 1E-3
WEIGHT_DECAY = 0
BATCH_SIZE = 1
NUM_CLASSES = 2 # [not bind, bind]
NUMBER_EPOCHS = 50
"""


TRAIN_BATCH_SIZE = 256
TEST_BATCH_SIZE = 256
# LR = 0.0005
LR = 1E-3
WEIGHT_DECAY = 0
LOG_INTERVAL = 20
NUM_EPOCHS = 1000

# GCNII parameters
INPUT_DIM = 206
OUTPUT_DIM = 128
NUM_FEATURES_XT = 954
N_OUTPUT = 2
HIDDEN_DIM = 256
LAYER = 10
DROPOUT = 0.1
ALPHA = 0.5
LAMBDA = 1.3
VARIANT = True # From GCNII

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def edge_index_to_adj(edge_index):
    num_nodes = edge_index.max().item() + 1  # 推断节点数量
    adj = torch.zeros((num_nodes, num_nodes), dtype=torch.float32)
    for i in range(edge_index.shape[1]):
        src = edge_index[0, i]
        dst = edge_index[1, i]
        adj[src, dst] = 1.0
        adj[dst, src] = 1.0  # 如果图是无向图，需要同时设置 (dst, src)
    return adj


# def embedding(sequence_name, seq, embedding_type):
#     if embedding_type == "b":
#         seq_embedding = []
#         Max_blosum = np.array([4, 5, 6, 6, 9, 5, 5, 6, 8, 4, 4, 5, 5, 6, 7, 4, 5, 11, 7, 4])
#         Min_blosum = np.array([-3, -3, -4, -4, -4, -3, -4, -4, -3, -4, -4, -3, -3, -4, -4, -3, -2, -4, -3, -3])
#         with open(Feature_Path + "blosum/blosum_dict.pkl", "rb") as f:
#             blosum_dict = pickle.load(f)
#         for aa in seq:
#             seq_embedding.append(blosum_dict[aa])
#         seq_embedding = (np.array(seq_embedding) - Min_blosum) / (Max_blosum - Min_blosum)
#     elif embedding_type == "e":
#         pssm_feature = np.load(Feature_Path + "pssm/" + sequence_name + '.npy')
#         hmm_feature = np.load(Feature_Path + "hmm/" + sequence_name + '.npy')
#         seq_embedding = np.concatenate([pssm_feature, hmm_feature], axis = 1)
#     return seq_embedding.astype(np.float32)
#
#
# def get_dssp_features(sequence_name):
#     dssp_feature = np.load(Feature_Path + "dssp/" + sequence_name + '.npy')
#     return dssp_feature.astype(np.float32)
#
#
# def norm_dis(mx): # from SPROF
#     return 2 / (1 + (np.maximum(mx, 4) / 4))


def normalize(mx):
    rowsum = np.array(mx.sum(1))
    r_inv = (rowsum ** -0.5).flatten()
    r_inv[np.isinf(r_inv)] = 0
    r_mat_inv = np.diag(r_inv)
    # result = r_mat_inv @ mx @ r_mat_inv
    result = np.dot(np.dot(r_mat_inv,mx),r_mat_inv)
    return result


# def load_graph(sequence_name):
#     dismap = np.load(Feature_Path + "distance_map/" + sequence_name + ".npy")
#     mask = ((dismap >= 0) * (dismap <= MAP_CUTOFF))
#     if MAP_TYPE == "d":
#         adjacency_matrix = mask.astype(int)
#     elif MAP_TYPE == "c":
#         adjacency_matrix = norm_dis(dismap)
#         adjacency_matrix = mask * adjacency_matrix
#     norm_matrix = normalize(adjacency_matrix.astype(np.float32))
#     return norm_matrix
def load_graph(sequence_name):
    fpath = './data/adjacency_matrix/discrete/' + sequence_name + '.npy'
    adjacency_matrix = np.load(fpath)
    norm_matrix = normalize(adjacency_matrix.astype(np.float32))
    return norm_matrix


def get_node_features(sequence_name):

    fpath = './data/node_features/fusion2/' + sequence_name + '.npy'
    node_features = np.load(fpath)

    # pssm_path = './data/node_features/pssm/' + sequence_name + '.npy'
    # blosum_path = './data/node_features/blosum/' + sequence_name + '.npy'
    # aaphy_path = './data/node_features/AAPHY/' + sequence_name + '.npy'
    # psp_path = './data/node_features/psp/' + sequence_name + '.npy'
    #
    # pssm = np.load(pssm_path)
    # blosum = np.load(blosum_path)
    # aaphy = np.load(aaphy_path)
    # psp = np.load(psp_path)
    #
    # node_features = np.concatenate([pssm, blosum, psp, aaphy], axis=1)

    return node_features


# class ProDataset(Dataset):
#     def __init__(self, dataframe):
#         # self.names = dataframe['ID'].values
#         # self.sequences = dataframe['sequence'].values
#         # self.labels = dataframe['label'].values
#
#         self.drug1s = dataframe['drug1'].values
#         self.drug2s = dataframe['drug2'].values
#         self.cell_names = dataframe['cell'].values
#         self.labels = dataframe['label'].values
#
#     def __getitem__(self, index):
#         # sequence_name = self.names[index]
#         # sequence = self.sequences[index]
#         # label = np.array(self.labels[index])
#
#         drug1_name = self.drug1s[index]
#         drug2_name = self.drug2s[index]
#         cell_name = self.cell_names[index]
#         label = np.array(self.labels[index])
#
#
#
#         node_features = get_node_features(sequence_name)
#         graph = load_graph(sequence_name)
#
#         return sequence_name, sequence, label, node_features, graph
#
#     def __len__(self):
#         return len(self.labels)

class DS_Dataset(Dataset):
    def __init__(self, dataframe):
        self.names = dataframe['ID'].values
        self.sequences = dataframe['sequence'].values
        self.labels = dataframe['label'].values

    def __getitem__(self, index):
        sequence_name = self.names[index]
        sequence = self.sequences[index]
        label = np.array(self.labels[index])


        node_features = get_node_features(sequence_name)
        graph = load_graph(sequence_name)

        return sequence_name, sequence, label, node_features, graph

    def __len__(self):
        return len(self.labels)


class GraphConvolution(torch.nn.Module):
    def __init__(self, in_features, out_features, residual=False, variant=False):
        super(GraphConvolution, self).__init__()
        self.variant = variant
        if self.variant:
            self.in_features = 2*in_features
        else:
            self.in_features = in_features

        self.out_features = out_features
        self.residual = residual
        self.weight = Parameter(torch.FloatTensor(self.in_features,self.out_features))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.out_features)
        self.weight.data.uniform_(-stdv, stdv)

    def forward(self, input, adj , h0 , lamda, alpha, l):
        theta = min(1, math.log(lamda/l+1))
        # print(adj.shape,input.shape)

        # print('++++++++++++++++')
        # print(adj.shape)
        # print(adj)
        # print(input.shape)
        # print('++++++++++++++++')

        # hi = torch.spmm(adj.to(device), input)
        hi = torch.spmm(adj.to(device), input.to(device))
        if self.variant:
            support = torch.cat([hi,h0],1)
            r = (1-alpha)*hi+alpha*h0
        else:
            support = (1-alpha)*hi+alpha*h0
            r = support
        output = theta*torch.mm(support, self.weight)+(1-theta)*r
        if self.residual: # speed up convergence of the training process
            output = output+input
        return output


class deepGCN(torch.nn.Module):
    def __init__(self, nlayers = LAYER, nfeat = INPUT_DIM, nhidden = HIDDEN_DIM,
                 dropout = DROPOUT, lamda = LAMBDA, alpha = ALPHA, variant = VARIANT,
                 output_dim = OUTPUT_DIM, num_features_xt = NUM_FEATURES_XT, n_output = N_OUTPUT):
        super(deepGCN, self).__init__()
        self.convs = nn.ModuleList()
        self.n_output = n_output
        for _ in range(nlayers):
            self.convs.append(GraphConvolution(nhidden, nhidden,variant=variant,residual=True))
        self.fcs = nn.ModuleList()
        self.fcs.append(nn.Linear(nfeat, nhidden))
        self.fcs.append(nn.Linear(nhidden, output_dim))
        self.act_fn = nn.ReLU()
        self.dropout = dropout
        self.alpha = alpha
        self.lamda = lamda

        # combined layers
        self.fc1 = nn.Linear(3 * output_dim, 512)
        self.fc2 = nn.Linear(512, 128)
        self.out = nn.Linear(128, self.n_output)

        # DL cell featrues
        self.reduction = nn.Sequential(
            nn.Linear(num_features_xt, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, output_dim)
        )

    # def forward(self, x, adj):
    #     _layers = []
    #     # print(x.shape,adj.shape)
    #     x = F.dropout(x, self.dropout, training=self.training)
    #     # print(x.shape)
    #     layer_inner = self.act_fn(self.fcs[0](x))
    #     # print('type layer_inner:{}'.format(type(layer_inner)),layer_inner.shape)
    #     _layers.append(layer_inner)
    #     for i,con in enumerate(self.convs):
    #         layer_inner = F.dropout(layer_inner, self.dropout, training=self.training)
    #         # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
    #         layer_inner = self.act_fn(con(layer_inner,adj,_layers[0],self.lamda,self.alpha,i+1))
    #         # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
    #     layer_inner = F.dropout(layer_inner, self.dropout, training=self.training)
    #     # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
    #     layer_inner = self.fcs[-1](layer_inner)
    #     # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
    #     # print('=================================================')
    #     return layer_inner

    def forward(self, data1, data2):

        x1, edge_index1, batch1, cell = data1.x, data1.edge_index, data1.batch, data1.cell
        x2, edge_index2, batch2 = data2.x, data2.edge_index, data2.batch

        adj1 = edge_index_to_adj(edge_index1)
        adj2 = edge_index_to_adj(edge_index2)

        # print('=========================')
        # print(adj1.shape,x1.shape)
        # print(adj2.shape,x2.shape)
        # print('=========================')
        # time.sleep(10000)

        drug1_layers = []
        # print(x.shape,adj.shape)
        x1 = F.dropout(x1, self.dropout, training=self.training)
        # print(x.shape)
        durg1_layer_inner = self.act_fn(self.fcs[0](x1))
        # print('type layer_inner:{}'.format(type(layer_inner)),layer_inner.shape)
        drug1_layers.append(durg1_layer_inner)
        for i, con in enumerate(self.convs):
            durg1_layer_inner = F.dropout(durg1_layer_inner, self.dropout, training=self.training)
            # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
            durg1_layer_inner = self.act_fn(con(durg1_layer_inner, adj1, drug1_layers[0], self.lamda, self.alpha, i + 1))
            # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
        durg1_layer_inner = gmp(durg1_layer_inner, batch1)  # global max pooling
        durg1_layer_inner = F.dropout(durg1_layer_inner, self.dropout, training=self.training)
        # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
        durg1_layer_inner = self.fcs[-1](durg1_layer_inner)

        drug2_layers = []
        # print(x.shape,adj.shape)
        x2 = F.dropout(x2, self.dropout, training=self.training)
        # print(x.shape)
        durg2_layer_inner = self.act_fn(self.fcs[0](x2))
        # print('type layer_inner:{}'.format(type(layer_inner)),layer_inner.shape)
        drug2_layers.append(durg2_layer_inner)
        for i, con in enumerate(self.convs):
            durg2_layer_inner = F.dropout(durg2_layer_inner, self.dropout, training=self.training)
            # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
            durg2_layer_inner = self.act_fn(
                con(durg2_layer_inner, adj2, drug2_layers[0], self.lamda, self.alpha, i + 1))
            # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
        durg2_layer_inner = gmp(durg2_layer_inner, batch1)  # global max pooling
        durg2_layer_inner = F.dropout(durg2_layer_inner, self.dropout, training=self.training)
        # print('type layer_inner:{}'.format(type(layer_inner)), layer_inner.shape)
        durg2_layer_inner = self.fcs[-1](durg2_layer_inner)

        # deal cell
        cell_vector = F.normalize(cell, 2, 1)
        cell_vector = self.reduction(cell_vector)

        # concat
        xc = torch.cat((durg1_layer_inner, durg2_layer_inner, cell_vector), 1)
        # add some dense layers
        xc = self.fc1(xc)
        xc = self.act_fn(xc)
        xc = F.dropout(xc)
        xc = self.fc2(xc)
        xc = self.act_fn(xc)
        xc = F.dropout(xc)
        out = self.out(xc)
        return out


class GraphPPIS(torch.nn.Module):
    def __init__(self, nlayers = LAYER, nfeat = INPUT_DIM, nhidden = HIDDEN_DIM, dropout = DROPOUT,
                 lamda = LAMBDA, alpha = ALPHA, variant = VARIANT, output_dim = OUTPUT_DIM,
                 num_features_xt = NUM_FEATURES_XT, n_output = N_OUTPUT):
        super(GraphPPIS, self).__init__()

        self.deep_gcn = deepGCN(nlayers = LAYER, nfeat = INPUT_DIM, nhidden = HIDDEN_DIM,
                                dropout = DROPOUT, lamda = LAMBDA, alpha = ALPHA, variant = VARIANT,
                                output_dim = OUTPUT_DIM, num_features_xt = NUM_FEATURES_XT, n_output = N_OUTPUT)
        self.criterion = nn.CrossEntropyLoss() # automatically do softmax to the predicted value and one-hot to the label
        self.optimizer = torch.optim.Adam(self.parameters(), lr = LR, weight_decay = WEIGHT_DECAY)

    def forward(self, data1, data2):          # x.shape = (seq_len, FEATURE_DIM); adj.shape = (seq_len, seq_len)
        # x = x.float()
        output = self.deep_gcn(data1, data2)  # output.shape = (seq_len, NUM_CLASSES)
        return output